import 'package:flutter/material.dart';
class hourlyweather extends StatelessWidget {
  final String label;
  final IconData icon;
  final String tem;
  const hourlyweather({super.key,
    required this.label,
    required this.icon,
    required this.tem,

  });

  @override
  Widget build(BuildContext context) {

    return SizedBox(width: 100,
      child:Card(
        elevation: 6,
        child:Container(
          width: 100,
          padding:const  EdgeInsets.all(8.0),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.0),
          ),
          child:Column(
            children: [
              const SizedBox(height: 8,),
              Text(label,
                style:const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 8,),
              Icon(icon,
                size: 32,
              ),
              const SizedBox(height: 8,),
              Text(tem,
                style: const TextStyle(
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 8,),
            ],
          ),
        ),
      ),
    );
  }
}